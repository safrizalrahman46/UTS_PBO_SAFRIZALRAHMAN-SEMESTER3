package JawbanNo1dan2;

import java.util.ArrayList;
import java.util.List;

public class Course19 {
    private String courseCode;
    private String courseName;
    private int credits;
    private Professor19 instructor;
    private List<Student19> enrolledStudents = new ArrayList<>();

    public Course19(String courseCode, String courseName, int credits, Professor19 instructor) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.credits = credits;
        this.instructor = instructor;
    }

    public void enrollStudent(Student19 student) {
        this.enrolledStudents.add(student);
    }

    public void unenrollStudent(Student19 student) {
        this.enrolledStudents.remove(student);
    }

    public List<Student19> getEnrolledStudents() {
        return this.enrolledStudents;
    }

    public float calculateAverageGrade() {
        // Implementation for calculating average grade
        return 0.0f;
    }
}
