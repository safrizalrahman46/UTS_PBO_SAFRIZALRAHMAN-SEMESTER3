package JawbanNo1dan2;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Professor19  extends Person19 {
    
        private float salary;
        private Department department;
        private List<Course19> coursesTaught = new ArrayList<>();
        private List<ResearchProject19> researchProjects = new ArrayList<>();
    
        public Professor19(String name, String phoneNumber, String emailAddress, Address19 address, Date dateOfBirth,
                         float salary, Department department) {
            super(name, phoneNumber, emailAddress, address, dateOfBirth);
            this.salary = salary;
            this.department = department;
        }
    
        public void assignCourse(Course19 course) {
            this.coursesTaught.add(course);
        }
    
        public List<Course19> getCoursesTaught() {
            return this.coursesTaught;
        }
    
        public void conductResearch(ResearchProject19 project) {
            this.researchProjects.add(project);
        }
    
        public void publishPaper(String title, String journal) {
            // Implementation
        
}
}
