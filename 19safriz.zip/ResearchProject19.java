package JawbanNo1dan2;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
public class ResearchProject19 {
    private String projectName;
    private String description;
    private Date startDate;
    private Date endDate;
    private List<Person19> researchers = new ArrayList<>();

    public ResearchProject19(String projectName, String description, Date startDate, Date endDate) {
        this.projectName = projectName;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public void addResearcher(Person19 researcher) {
        this.researchers.add(researcher);
    }

    public void removeResearcher(Person19 researcher) {
        this.researchers.remove(researcher);
    }

    public int getProjectDuration() {
        // Calculate the duration in days
        long duration = endDate.getTime() - startDate.getTime();
        return (int) (duration / (1000 * 60 * 60 * 24));
    }
}
