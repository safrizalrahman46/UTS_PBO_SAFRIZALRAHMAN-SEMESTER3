package JawbanNo1dan2;

import java.util.Date;
public class Person19 {
        private String name;
        private String phoneNumber;
        private String emailAddress;
        private Address19 address;
        private Date dateOfBirth;
    
        public Person19(String name, String phoneNumber, String emailAddress, Address19 address, Date dateOfBirth) {
            this.name = name;
            this.phoneNumber = phoneNumber;
            this.emailAddress = emailAddress;
            this.address = address;
            this.dateOfBirth = dateOfBirth;
        }
    
        public void purchaseParkingPass() {
            // Implementation
            System.out.println(name + " purchased a parking pass.");
        }
    
        public void updateContactDetails(String phoneNumber, String emailAddress) {
            this.phoneNumber = phoneNumber;
            this.emailAddress = emailAddress;
        }
    
        public String getFullName() {
            return this.name;
        }
    
        // Overloaded methods for updating contact details
        public void updateContactDetails(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }
    
        public void updateContactDetails() {
            this.phoneNumber = "Unknown";
            this.emailAddress = "Unknown";
        }
    }
    

