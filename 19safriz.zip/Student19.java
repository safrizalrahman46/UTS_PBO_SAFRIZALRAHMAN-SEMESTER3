package JawbanNo1dan2;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Student19 extends Person19 {
    private String studentNumber;
    private float averageMark;
    private List<Course19> courseEnrollments = new ArrayList<>();
    private float GPA;

    public Student19(String name, String phoneNumber, String emailAddress, Address19 address, Date dateOfBirth,
                   String studentNumber, float averageMark) {
        super(name, phoneNumber, emailAddress, address, dateOfBirth);
        this.studentNumber = studentNumber;
        this.averageMark = averageMark;
    }

    public boolean isEligibleToEnroll() {
        // Implementation
        return true;
    }

    public void enrollInCourse(Course19 course) {
        this.courseEnrollments.add(course);
    }

    public List<Course19> getCoursesTaken() {
        return this.courseEnrollments;
    }

    public void calculateGPA() {
        // Implementation
    }

    // Overridden method
    @Override
    public void updateContactDetails(String phoneNumber, String emailAddress) {
        super.updateContactDetails(phoneNumber, emailAddress);
        System.out.println("Updated contact details for student: " + getFullName());
    }
}
