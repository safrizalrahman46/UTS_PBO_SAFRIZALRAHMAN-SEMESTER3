package JawbanNo1dan2;
class Address19 {
    private String street;
    private String city;
    private String state;
    private String postalCode;
    private String country;

    public Address19(String street, String city, String state, String postalCode, String country) {
        this.street = street;
        this.city = city;
        this.state = state;
        this.postalCode = postalCode;
        this.country = country;
    }

    public boolean validate() {
        // Validate the address fields
        return street != null && !street.isEmpty() && city != null && !city.isEmpty();
    }

    public String outputAsLabel() {
        return street + ", " + city + ", " + state + ", " + postalCode + ", " + country;
    }
}
